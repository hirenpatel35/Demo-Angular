import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EventsHomeComponent } from './home/events-home/events-home.component';
import { EventsListComponent } from './events/events-list/events-list.component';
import { EmployeesListComponent } from './employees/employees-list/employees-list.component';
import { JphUserPostsComponent } from './jph/jph-user-posts/jph-user-posts.component';

const routes: Routes = [
  {
    path: "",
    component: EventsHomeComponent,
  },
  {
    path: "events",
    component: EventsListComponent,
  },
  {
    path: "employees",
    component: EmployeesListComponent,
  },
  {
    path: "userposts",
    component: JphUserPostsComponent,
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
