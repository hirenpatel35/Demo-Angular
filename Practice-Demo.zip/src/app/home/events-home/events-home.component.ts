import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-events-home',
  templateUrl: './events-home.component.html',
  styleUrls: ['./events-home.component.css']
})
export class EventsHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
