import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeesListComponent } from './employees-list/employees-list.component';
import { EmployeesDetailsComponent } from './employees-details/employees-details.component';
import {HttpClientModule} from '@angular/common/http'



@NgModule({
  declarations: [
    EmployeesListComponent,
    EmployeesDetailsComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule
  ],
  exports:[EmployeesListComponent]
})
export class EmployeesModule { }
