import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EventsListComponent } from './events-list/events-list.component';
import { EventDetailsComponent } from './event-details/event-details.component';
import { SortingPipe } from './pipes/sorting.pipe';
import { HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [
    EventsListComponent,
    EventDetailsComponent,
    SortingPipe
  ],
  imports: [
    CommonModule,
    HttpClientModule
  ],
  exports:[EventsListComponent],
 
})
export class EventsModule { }
