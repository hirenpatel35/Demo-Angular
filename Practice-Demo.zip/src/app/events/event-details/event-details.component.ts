import { Component, OnChanges, Input, OnDestroy } from '@angular/core';
import { Event } from '../models/event';
import { EventsService } from '../services/events.service';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.css'],
 
})
export class EventDetailsComponent implements OnChanges, OnDestroy {

  constructor(private _eventsService: EventsService) { }

  /*
  ngOnInit(): void {
  }*/

  private _eventsServiceSubsription: Subscription;
  @Input() public eventId: number;
  public eventDetails: Event;

  ngOnChanges(): void {
    this._eventsService.getEventDetails(this.eventId).subscribe(
      data => this.eventDetails = data,
      error => console.log(error),
      () => console.log("service completed")
    );
  }

  ngOnDestroy(): void {
    if (this._eventsServiceSubsription) {
      this._eventsServiceSubsription.unsubscribe()
    }
  }

}
